const cardSymbols = ["🚀", "🎧", "🌈", "🍀", "🪐", "🎮", "🦋", "⚡"];
const board = document.querySelector("#game-board");
const movesElement = document.querySelector("#moves");
const matchedElement = document.querySelector("#matched");
const timerElement = document.querySelector("#timer");
const progressElement = document.querySelector("#progress");
const messageElement = document.querySelector("#message");
const restartButton = document.querySelector("#restart");
let firstCard = null, secondCard = null, lockBoard = false;
let moves = 0, matchedPairs = 0, seconds = 0, timerInterval = null, hasStarted = false;

function shuffle(items) {
  const shuffled = [...items];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const randomIndex = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[randomIndex]] = [shuffled[randomIndex], shuffled[i]];
  }
  return shuffled;
}

function createCard(symbol, index) {
  const card = document.createElement("button");
  card.type = "button";
  card.className = "memory-card";
  card.dataset.symbol = symbol;
  card.setAttribute("aria-label", `Hidden card ${index + 1}`);
  card.innerHTML = `<span class="card-inner"><span class="card-back" aria-hidden="true">?</span><span class="card-front" aria-hidden="true">${symbol}</span></span>`;
  card.addEventListener("click", () => flipCard(card));
  return card;
}

function startGame() {
  stopTimer(); board.innerHTML = "";
  firstCard = null; secondCard = null; lockBoard = false;
  moves = 0; matchedPairs = 0; seconds = 0; hasStarted = false;
  movesElement.textContent = "0"; matchedElement.textContent = "0";
  timerElement.textContent = "00:00"; progressElement.style.width = "0%";
  messageElement.classList.remove("is-win");
  messageElement.innerHTML = '<span class="message-icon" aria-hidden="true">✦</span><span>Ready when you are. Find your first pair!</span>';
  shuffle([...cardSymbols, ...cardSymbols]).forEach((symbol, index) => board.appendChild(createCard(symbol, index)));
}

function startTimer() {
  if (hasStarted) return;
  hasStarted = true;
  timerInterval = window.setInterval(() => {
    seconds++;
    const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
    const remainingSeconds = (seconds % 60).toString().padStart(2, "0");
    timerElement.textContent = `${minutes}:${remainingSeconds}`;
  }, 1000);
}
function stopTimer() { if (timerInterval !== null) { window.clearInterval(timerInterval); timerInterval = null; } }

function flipCard(card) {
  if (lockBoard || card === firstCard || card.classList.contains("is-flipped") || card.classList.contains("is-matched")) return;
  startTimer(); card.classList.add("is-flipped");
  card.setAttribute("aria-label", `Revealed ${card.dataset.symbol}`);
  if (!firstCard) { firstCard = card; return; }
  secondCard = card; moves++; movesElement.textContent = moves.toString(); checkForMatch();
}

function checkForMatch() {
  if (firstCard.dataset.symbol === secondCard.dataset.symbol) {
    firstCard.classList.add("is-matched"); secondCard.classList.add("is-matched");
    firstCard.setAttribute("aria-label", `Matched ${firstCard.dataset.symbol}`);
    secondCard.setAttribute("aria-label", `Matched ${secondCard.dataset.symbol}`);
    matchedPairs++; matchedElement.textContent = matchedPairs.toString();
    progressElement.style.width = `${(matchedPairs / cardSymbols.length) * 100}%`;
    resetTurn(); if (matchedPairs === cardSymbols.length) finishGame();
    return;
  }
  lockBoard = true;
  window.setTimeout(() => {
    firstCard.classList.remove("is-flipped"); secondCard.classList.remove("is-flipped");
    firstCard.setAttribute("aria-label", "Hidden card"); secondCard.setAttribute("aria-label", "Hidden card");
    resetTurn();
  }, 850);
}
function resetTurn() { [firstCard, secondCard] = [null, null]; lockBoard = false; }
function finishGame() {
  stopTimer(); messageElement.classList.add("is-win");
  messageElement.innerHTML = `<span class="message-icon" aria-hidden="true">✦</span><span>Perfect match! You found all pairs in ${moves} moves and ${timerElement.textContent}.</span>`;
}
restartButton.addEventListener("click", startGame);
startGame();
